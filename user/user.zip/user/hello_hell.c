int
main(int argc, char * argv[])
{
	(void)argc;
	(void)argv;

	int a = 1;
	int b = 2;
	int c = a + b;
	(void) c;
	return 0;
}
